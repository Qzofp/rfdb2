/**
 * @typedef {(number|string|Date)} DateLike
 */

/**
 * @typedef {'day'|'month'|'year'} CellType
 */

/**
 * @typedef {'days'|'months'|'years'} ViewType
 */


