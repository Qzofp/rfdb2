import Param from './param';
import ParamType from './paramType';
export default Param;
export {ParamType}

