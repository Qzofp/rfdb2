import Link from './link';
export default Link;

