import Example from './example';
export default Example;

