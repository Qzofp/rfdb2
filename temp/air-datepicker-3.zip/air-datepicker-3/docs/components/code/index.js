import Code from './code';
export default Code;

