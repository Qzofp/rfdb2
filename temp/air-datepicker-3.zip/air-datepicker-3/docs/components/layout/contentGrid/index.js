import ContentGrid from './contentGrid';
export default ContentGrid;

