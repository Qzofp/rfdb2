export default [
    {
        labelId: 'navExamples',
        href: '/examples'
    },
    {
        labelId: 'navDoc',
        href: '/docs'
    },
    {
        labelId: 'navApi',
        href: '/methods'
    }
]
