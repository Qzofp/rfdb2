module.exports = {
    plugins: [
        'autoprefixer'
    ]
};
